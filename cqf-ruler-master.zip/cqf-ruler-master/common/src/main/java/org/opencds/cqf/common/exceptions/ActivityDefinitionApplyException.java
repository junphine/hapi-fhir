package org.opencds.cqf.common.exceptions;

public class ActivityDefinitionApplyException extends RuntimeException {
    private static final long serialVersionUID = 1L;

    public ActivityDefinitionApplyException(String message) {
        super(message);
    }
}
