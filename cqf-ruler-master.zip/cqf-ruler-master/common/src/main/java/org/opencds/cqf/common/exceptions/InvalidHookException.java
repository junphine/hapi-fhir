package org.opencds.cqf.common.exceptions;

public class InvalidHookException extends RuntimeException {
    private static final long serialVersionUID = 1L;

    public InvalidHookException(String message) {
        super(message);
    }

}
